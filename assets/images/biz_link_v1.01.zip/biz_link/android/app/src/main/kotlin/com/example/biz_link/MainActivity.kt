package com.example.biz_link

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
